#!/bin/sh


cur_dir=`pwd`

install_cython()
{
    tar zxvf Cython-0.16.tar.gz;
    cd Cython-0.16;
    python26 setup.py install;
    ln -s /usr/local/python/bin/cython /usr/local/bin/cython;
    cd ${cur_dir};
}

install_pycmem()
{
    tar zxvf PyCmem-1.0.tar.gz;
    cd PyCmem-1.0;
    python26 setup.py install;
    cd ${cur_dir};
}


case $1 in
    cython)
        echo "start build..........";
        install_cython;
        ;;
    pycmem)
        echo "start build..........";
        install_pycmem;
        ;;        
    all)
        echo "start clean..........";
        install_cython;
        install_pycmem;
        ;;
    *)
        echo " Usage: $0 { cython | pycmem | all }";
esac

exit 0